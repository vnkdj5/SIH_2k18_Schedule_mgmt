<?php 
    include('way2sms-api.php');
    sendSMS('9890881301', 'YOOOO DJ');
    #$client->logout();
?>
